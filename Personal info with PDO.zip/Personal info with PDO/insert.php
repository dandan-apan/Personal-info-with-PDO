<?php
include ('connection.php');

if(isset($_POST['submit']))
{
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name']; 
    $last_name = $_POST['last_name']; 
    $gender = $_POST['gender']; 
    $birthday= $_POST['birthday']; 
    $age = $_POST['age']; 
    $year = $_POST['year']; 
    $course = $_POST['course']; 

    $query = "INSERT INTO per_info (first_name, middle_name, last_name, gender, birthday, age, year, course) VALUES (:first_name, :middle_name, :last_name, :gender, :birthday, :age, :year, :course)";
    $query_run = $conn->prepare($query);
    $data = [
        ':first_name' => $first_name,
        ':middle_name' => $middle_name,
        ':last_name' => $last_name,
        ':gender' => $gender,
        ':birthday' => $birthday,
        ':age' => $age,
        ':year' => $year,
        ':course' => $course,
    ];

    $query_execute = $query_run->execute($data);

    if($query_execute)
    {
        
        header('Location: index.php');
        exit(0);

    }
    else{
       echo "<script>alert('Not Inserted');</script>";
       header('Location: index.php');
       exit(0);

    }


    
}


?>