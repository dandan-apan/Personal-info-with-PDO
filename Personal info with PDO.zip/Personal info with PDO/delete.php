<?php
   include('connection.php');

   try{

    $query = "DELETE FROM per_info WHERE id=" . $_GET['id'];
    $statement = $conn->prepare($query);

 $query_execute = $statement->execute();
 if($query_execute)
 {
     
    header("Location: index.php");
     exit(0);

 }
 else{
    echo "<script>alert('Not Deleted');</script>";
    header('Location: index.php');
    exit(0);

 }

   }

   catch(PDOException $e){

    echo $e->getMessage();

   }



?>