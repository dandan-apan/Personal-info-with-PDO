<?php
session_start();

include ('connection.php');

if(isset($_POST['submit'])){
    if($_POST['name'] != "" || $_POST['uname'] != "" || $_POST['email'] != "" || $_POST['pword'] != "" || $_POST['cpword'] != ""){
        try{
            $name = $_POST['name'];
            $uname = $_POST['uname'];
            $email = $_POST['email'];
            $pword = $_POST['pword'];
            $cpword = $_POST['cpword'];
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO `user` VALUES ('', '$name', '$uname', '$email', '$pword', '$cpword')";
            $conn->exec($sql);
        }catch(PDOException $e){
            echo $e->getMessage();
        }
        $_SESSION['message']=array("text"=>"User successfully created.","alert"=>"info");
        $conn = null;
        header('location:login.php');
    }else{
        echo "
            <script>alert('Please fill up the required field!')</script>
            <script>window.location = 'registration.php'</script>
        ";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
</head>
<body>
<a href="login.php"><- Back</a>
    <h2>Registration</h2>
    <form class="" action="" method="post" autocomplete="off">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required value="">
        <br>
        <br>
        <label for="uname">Username:</label>
        <input type="text" id="uname" name="uname" required value="">
        <br>
        <br>
        <label for="email">Email:</label>
        <input type="text" id="email" name="email" required value="">
        <br>
        <br>
        <label for="pword">Password:</label>
        <input type="password" id="pword" name="pword" required value="">
        <br>
        <br>
        <label for="cpword">Confirm Password:</label>
        <input type="password" id="cpword" name="cpword" required value="">
        <br>
        <br>
        <input type="submit" id="btn" value="Register" name="submit"/> 
    </form>
    
</body>
</html>