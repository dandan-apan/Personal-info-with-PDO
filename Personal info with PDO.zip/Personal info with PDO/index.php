<?php
include ('connection.php');
// session_start();

if(!empty($_SESSION["id"])){
    $id = $_SESSION["id"];
    $result = mysqli_query($conn, "SELECT * FROM user WHERE id = $id");
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Info</title>
</head>
<body>
    
    
    
    <h1>Personal Info</h1>

    <form action="insert.php" method="POST">
    <label for="">Enter firstname: </label><br>
    <input type="text" name="first_name" id="first_name"><br><br>
    
    <label for="">Enter middle name: </label><br>
    <input type="text" name="middle_name"><br><br>

    <label for="">Enter last name: </label><br>
    <input type="text" name="last_name"><br>

    
    <p>Enter gender:</p>
    <input type="radio" id="gender" name="gender" value="Male">
    <label for="">Male</label>
    <input type="radio" id="gender" name="gender" value="Female">
    <label for="">Female</label><br><br>

    <label for="">Enter birthday: </label><br>
    <input type="date" name="birthday"><br><br>

    <label for="">Enter age: </label><br>
    <input type="number" name="age"><br><br>

    

    <label for="">Enter year:</label>
  <select name="year" id="year">
    <option value="1st year">1st year</option>
    <option value="2nd year">2nd year</option>
    <option value="3rd year">3rd year</option>
    <option value="4th year">4th year</option>
  </select>
  <br><br>

    

    <label for="">Enter course:</label>
  <select name="course" id="course">
    <option value="BSIT">BSIT</option>
    <option value="BSBA">BSBA</option>
    <option value="BSED">BSED</option>
  </select>
  <br><br>
    
    <button type="submit" name="submit">Submit</button>
    <br>
    <br>
</form>


<table border="1">
    <thead>
    <tr>
    <th>ID</th>
    <th>FIRST NAME</th>
    <th>MIDDLE NAME</th>
    <th>LAST NAME</th>
    <th>GENDER</th>
    <th>BIRTHDAY</th>
    <th>AGE</th>
    <th>YEAR</th>
    <th>COURSE</th>
    <th>ACTION</th>
    </tr>
    </thead>
    <tbody>
    <?php
    include ('connection.php');;

    $query = "SELECT * FROM per_info";
    $statement = $conn->prepare($query);
    $statement->execute();

    $statement->setFetchMode(PDO::FETCH_OBJ);
    $result = $statement->fetchAll();
    if($result) {
        foreach($result as $row) { ?>
        <tr>
        
        
        <td><?= $row->id; ?></td>
        <td><?= $row->first_name; ?></td>
        <td><?= $row->middle_name; ?></td>
        <td><?= $row->last_name; ?></td>
        <td><?= $row->gender; ?></td>
        <td><?= $row->birthday; ?></td>
        <td><?= $row->age; ?></td>
        <td><?= $row->year; ?></td>
        <td><?= $row->course; ?></td>
        <td>
            <a href="delete.php?id=<?= $row->id; ?>">Delete</a>
            <a href="edit.php?id=<?= $row->id; ?>&first_name=<?= $row->first_name; ?>&middle_name=<?= $row->middle_name; ?>&last_name=<?= $row->last_name;?>&gender=<?= $row->gender; ?>&birthday=<?= $row->birthday;?>&age=<?= $row->age; ?>&year=<?= $row->year; ?>&course<?= $row->course; ?>">Edit</a>
        </td>
        </tr>
        <?php
        } // end of while loop...
    } else {
        echo "<tr><td colspan='10' style='text-align: center;'>No results found.</td></tr>";
    }
    ?>
    </tbody>
    <br>
</table>
    <br>
    <a href="logout.php">Log out</a>
    
</body>
</html>