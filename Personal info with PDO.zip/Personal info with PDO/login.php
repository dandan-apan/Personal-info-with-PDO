<?php
session_start();
include ('connection.php');
$dsn = 'mysql:host=localhost;dbname=tb_user';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $unameemail = $_POST['unameemail'];
    $pword = $_POST['pword'];

  
    $sql = "SELECT * FROM user WHERE uname = :unameemail OR email = :unameemail";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':unameemail', $unameemail);
    $stmt->bindParam(':pword', $pword);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    
    if ($user) {
        header("Location: index.php"); 
        
        exit;
    } else {
        echo 'Invalid name or email';
    }
}
    
    


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <div id="form">
        <h1>Login Form</h1>

        <?php if(isset($_SESSION['message'])): ?>
				<div class="alert alert-<?php echo $_SESSION['message']['alert'] ?> msg"><?php echo $_SESSION['message']['text'] ?></div>
			<script>
				(function() {
					
					setTimeout(function(){
						document.querySelector('.msg').remove();
					},3000)
				})();
			</script>
			<?php 
				endif;
				
				unset($_SESSION['message']);
			?>

            <br>

        <form name="form" method="POST">
            <label>Username or Email:</label>
            <input type="text" id="unameemail" name="unameemail" required value="">
            <br>
            <br>
            <label>Password</label>
            <input type="password" id="pword" name="pword" required value="">
            <br>
            <br>

            <button type="submit" name="submit">Login</button> 
            <br>
            <br>
            <p>If you haven't account click register <a href="registration.php">Register</a><p>


</form>
</div>
    
</body>
</html>