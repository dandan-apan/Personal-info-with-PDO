<?php
include ('connection.php');

if(isset($_POST['update']))
{
    $per_id = $_POST['per_id'];
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name']; 
    $last_name = $_POST['last_name']; 
    $gender = $_POST['gender']; 
    $birthday= $_POST['birthday']; 
    $age = $_POST['age']; 
    $year = $_POST['year']; 
    $course = $_POST['course']; 

try{

    $query = "UPDATE per_info SET first_name=:first_name, middle_name=:middle_name, last_name=:last_name, gender=:gender, birthday=:birthday, age=:age, year=:year, course=:course WHERE id=:per_id";
    $query_run = $conn->prepare($query);
    $data = [
        ':per_id' => $per_id,
        ':first_name' => $first_name,
        ':middle_name' => $middle_name,
        ':last_name' => $last_name,
        ':gender' => $gender,
        ':birthday' => $birthday,
        ':age' => $age,
        ':year' => $year,
        ':course' => $course,
    ];
    $query_execute = $query_run->execute($data);

    if($query_execute)
    {
        
        header('Location: index.php');
        exit(0);

    }
    else{
       echo "<script>alert('Not Updated');</script>";
       header('Location: index.php');
       exit(0);

    }

} catch (PDOException $e){
    echo $e->getMessage();
}


    
}


?>